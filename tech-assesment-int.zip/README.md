This is a JavaScript task.
File structure is set up and don't need to be touched. By loading index.html directly in the browser you can see if your results are correct.
You only need to work in main.js file, inside of the function outputDate();

Please set up timer. And afterwards specify how much time it took you to finish the task.

After the tasks are finished, create either gist on github of main.js and send the link or archive all files and send them back to us.